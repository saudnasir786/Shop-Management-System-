﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using Azure;

namespace DBMS
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            string query = "SELECT * FROM [shopmanagement].[dbo].[user] WHERE email= '" + textBox2.Text+"'";
            SqlCommand cm = new SqlCommand(query, con);
            SqlDataReader da = cm.ExecuteReader();
             
            if (da.Read())
            {
                    cm.Dispose();
                    con.Close();
                    MessageBox.Show("This Email is already Registered");
            }
            else
            {
                    cm.Dispose();
                    con.Close();
                    if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
                {
                    MessageBox.Show("Fill all the required information");
                }
                else
                {

                    con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                    con.Open();
                   
                    string m1 = textBox1.Text;
                    string m2 = textBox2.Text;
                    string m3 = textBox3.Text;
                    string m4 = textBox4.Text;

                    query = "INSERT INTO [dbo].[user] (email,name,password,number) VALUES (@Operand1, @Operand2, @Operand3, @Operand4)";

                    cm = new SqlCommand(query, con);
                    cm.Parameters.AddWithValue("@Operand1", m2);
                    cm.Parameters.AddWithValue("@Operand2", m1);
                    cm.Parameters.AddWithValue("@Operand3", m3);
                    cm.Parameters.AddWithValue("@Operand4", m4);
                    cm.ExecuteNonQuery();
                    cm.Dispose();
                    con.Close();
                    MessageBox.Show("Successfully Registered !");
                }
            }
        }
            else
            {
                MessageBox.Show("Enter Email");
            }
        }
            
           
            
        

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
