﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBMS
{
    public partial class Form8 : Form
    {
        public string email { get; set; }
        public Form8()
        {
            InitializeComponent();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Enter all the required information");
            }
            else
            {

                SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                con.Open();
                string query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE email = '" + email + "' AND p_id= "+ textBox1.Text + "";
                SqlCommand cm = new SqlCommand(query, con);
                SqlDataReader da = cm.ExecuteReader();
                if (da.Read())
                {
                    da.Close();
                    cm.Dispose();
                    con.Close();
                    con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                    con.Open();
                    query = "SELECT * FROM [shopmanagement].[dbo].[sale] WHERE sale_id = (SELECT MAX(sale_id) FROM [shopmanagement].[dbo].[sale])";
                    cm = new SqlCommand(query, con);
                    da = cm.ExecuteReader();
                    if (da.Read())
                    {
                        string strId = da["sale_id"].ToString();
                        da.Close();
                        cm.Dispose();
                        con.Close();
                        double id = double.Parse(strId);
                        id = id + 1;
                        strId = Convert.ToString(id);
                        con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                        con.Open();
                        query = "SELECT * FROM [shopmanagement].[dbo].[sale] WHERE email = '" + email + "' AND p_id=" + textBox1.Text + "";
                        cm = new SqlCommand(query, con);
                        da = cm.ExecuteReader();
                        if (da.Read())
                        {

                            string t_Price = da["p_price"].ToString();
                            string t_Qty = da["p_qty"].ToString();
                            double total_Qty = double.Parse(t_Qty);
                            double total_Price = double.Parse(t_Price);
                            da.Close();
                            cm.Dispose();
                            con.Close();
                            con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                            con.Open();
                            query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE email = '" + email + "' AND p_id=" + textBox1.Text;
                            cm = new SqlCommand(query, con);
                            da = cm.ExecuteReader();
                            da.Read();
                            string qty2 = da["p_qty"].ToString();
                            double qt = double.Parse(textBox2.Text);
                            double qt2 = double.Parse(qty2);
                            string strPrice = da["p_price"].ToString();
                            double price = double.Parse(strPrice);
                            da.Close();
                            cm.Dispose();
                            con.Close();
                            if (qt > qt2)
                            {
                                MessageBox.Show("Insufficient Product Quantity");
                            }
                            else
                            {
                                total_Qty = total_Qty + qt;
                                qt2 = qt2 - qt;
                                total_Price = price * total_Qty;
                                string strTotalQty = Convert.ToString(total_Qty);
                                string strTotalPrice = Convert.ToString(total_Price);
                                string strQ2 = Convert.ToString(qt2);
                                con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                                con.Open();
                                query = "UPDATE [shopmanagement].[dbo].[productDetail] SET p_qty='" + strQ2 + "' WHERE p_id=" + textBox1.Text;
                                cm = new SqlCommand(query, con);
                                cm.ExecuteNonQuery();
                                cm.Dispose();
                                con.Close();
                                con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                                con.Open();
                                query = "UPDATE [shopmanagement].[dbo].[sale] SET p_qty='" + strTotalQty + "', p_price='" + strTotalPrice + "' WHERE p_id='" + textBox1.Text + "' AND email='" + email + "'";
                                cm = new SqlCommand(query, con);
                                cm.ExecuteNonQuery();
                                cm.Dispose();
                                con.Close();
                                MessageBox.Show("Product Sold Successfully");
                                this.Close();
                            }


                        }
                        else
                        {
                            da.Close();
                            cm.Dispose();
                            con.Close();
                            con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                            con.Open();
                            query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE email = '" + email + "' AND p_id="+ textBox1.Text;
                            cm = new SqlCommand(query, con);
                            da = cm.ExecuteReader();
                            da.Read();
                            string p_name = da["p_name"].ToString();
                            string qty2 = da["p_qty"].ToString();
                            double qt = double.Parse(textBox2.Text);
                            double qt2 = double.Parse(qty2);
                            string strPrice = da["p_price"].ToString();
                            double price = double.Parse(strPrice);
                            da.Close();
                            cm.Dispose();
                            con.Close();
                            if (qt > qt2)
                            {
                                MessageBox.Show("Insufficient Product Quantity");
                            }
                            else
                            {
                                double remaining_Qty = qt2 - qt;
                                double total_price = price * qt;
                                strPrice = Convert.ToString(total_price);
                                string strQ2 = Convert.ToString(remaining_Qty);
                                con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                                con.Open();
                                query = "UPDATE [shopmanagement].[dbo].[productDetail] SET p_qty='" + strQ2 + "' WHERE p_id=" + textBox1.Text;
                                cm = new SqlCommand(query, con);
                                cm.ExecuteNonQuery();
                                cm.Dispose();
                                con.Close();
                                con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                                con.Open();
                                query = "INSERT INTO [shopmanagement].[dbo].[sale] (sale_id,p_name,email,p_qty,p_price,p_id) VALUES (" + strId + ",'" + p_name + "','" + email + "','" + textBox2.Text + "','" + strPrice + "'," + textBox1.Text + ")";
                                cm = new SqlCommand(query, con);
                                cm.ExecuteNonQuery();
                                cm.Dispose();
                                con.Close();
                                MessageBox.Show("Product Sold Successfully");
                                this.Close();
                            }


                        }



                    }
                    else
                    {
                        da.Close();
                        cm.Dispose();
                        con.Close();
                        string strId = "1";
                        con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                        con.Open();
                        query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE email = '" + email + "' AND p_id=" + textBox1.Text;
                        cm = new SqlCommand(query, con);
                        da = cm.ExecuteReader();
                        da.Read();
                        string p_name = da["p_name"].ToString();
                        string qty2 = da["p_qty"].ToString();
                        double qt = double.Parse(textBox2.Text);
                        double qt2 = double.Parse(qty2);
                        string strPrice = da["p_price"].ToString();
                        double price = double.Parse(strPrice);
                        da.Close();
                        cm.Dispose();
                        con.Close();
                        if (qt > qt2)
                        {
                            MessageBox.Show("Insufficient Product Quantity");
                        }
                        else
                        {
                            double remaining_Qty = qt2 - qt;
                            double total_price = price * qt;
                            strPrice = Convert.ToString(total_price);
                            string strQ2 = Convert.ToString(remaining_Qty);
                            con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                            con.Open();
                            query = "UPDATE [shopmanagement].[dbo].[productDetail] SET p_qty='" + strQ2 + "' WHERE p_id=" + textBox1.Text;
                            cm = new SqlCommand(query, con);
                            cm.ExecuteNonQuery();
                            cm.Dispose();
                            con.Close();
                            con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                            con.Open();
                            query = "INSERT INTO [shopmanagement].[dbo].[sale] (sale_id,p_name,email,p_qty,p_price,p_id) VALUES (" + strId + ",'" + p_name + "','" + email + "','" + textBox2.Text + "','" + strPrice + "'," + textBox1.Text + ")";
                            cm = new SqlCommand(query, con);
                            cm.ExecuteNonQuery();
                            cm.Dispose();
                            con.Close();
                            MessageBox.Show("Product Sold Successfully");
                            this.Close();
                        }


                    }


                }
                else
                {
                    MessageBox.Show("Product not Found");
                }

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
