﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using Azure;

namespace DBMS
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            
            string email = textBox1.Text;
            string password = textBox2.Text;
            string email2;
            string query = "select * from [shopmanagement].[dbo].[user] where email='"+email+"'";
            SqlCommand cm=new SqlCommand(query,con);
            
            SqlDataReader da= cm.ExecuteReader();
            if (da.Read())
            {
      
                email2 = da["email"].ToString();
                if (email != email2)
                {
                    MessageBox.Show("email found");
                }
                else
                {
                    
                    string pass2 = da["password"].ToString();
                    if (password==pass2)
                    {
                        da.Close();
                        con.Close();
                        Form4 form4= new Form4();
                        form4.email = email2;
                        
                        form4.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Password !");
                    }

                }
            }
            else
            {
                MessageBox.Show("Email not found");
            }   

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ;
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
    }
}
