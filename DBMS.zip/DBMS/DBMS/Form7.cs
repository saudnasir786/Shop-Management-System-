﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Azure;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DBMS
{
    public partial class Form7 : Form
    {
        public string email { get; set; }
        public Form7()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.email = email;
            form9.name = "Price";
            form9.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.email = email;
            form9.name = "Quantity";
            form9.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();
            form9.email = email;
            form9.name = "Weight";
            form9.Show();
            this.Close();
        }
    }

}
