﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBMS
{
    public partial class Form9 : Form
    {
        public string email { get; set; }
        public string name { get; set; }
        public Form9()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            label2.Text = "Enter Product " + name + " To Update";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string val = "";
            if (name == "Price")
            {
                val = "p_price";
            }
            else if (name == "Quantity")
            {
                val = "p_qty";
            }
            else if (name == "Weight")
            {
                val = "p_weight";
            }
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Enter all the required information");
            }
            else
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                con.Open();
                string query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE p_id= " + textBox1.Text + "AND email = '" + email + "'";
                SqlCommand cm = new SqlCommand(query, con);
                SqlDataReader da = cm.ExecuteReader();
                if (da.Read())
                {
                    da.Close();
                    cm.Dispose();
                    con.Close();
                    con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                    con.Open();
                    query = "UPDATE [shopmanagement].[dbo].[productDetail] SET " + val + "='" + textBox2.Text + "' WHERE p_id='" + textBox1.Text + "'";
                    cm = new SqlCommand(query, con);
                    cm.ExecuteNonQuery();
                    cm.Dispose();
                    con.Close();
                    MessageBox.Show("Product Updated Successfully");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Product Not Found");

                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
