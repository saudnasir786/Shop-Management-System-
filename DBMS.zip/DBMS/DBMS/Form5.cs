﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using Azure;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DBMS
{
    public partial class Form5 : Form
    {
        public string email { get; set; }
        public Form5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Enter all the required information");
            }
            else
            {


                SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                con.Open();
                string query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE p_id = (SELECT MAX(p_id) FROM [shopmanagement].[dbo].[productDetail])";
                SqlCommand cm = new SqlCommand(query, con);
                SqlDataReader da = cm.ExecuteReader();
                if (da.Read())
                {
                    string strId = da["p_id"].ToString();
                    da.Close();
                    cm.Dispose();
                    con.Close();
                    double id = double.Parse(strId);
                    id = id + 1;
                    strId = Convert.ToString(id);
                    string p_Name = textBox1.Text;
                    string p_Price = textBox2.Text;
                    string p_Qty = textBox3.Text;
                    string p_Weight = textBox4.Text;
                    con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                    con.Open();
                    query = "INSERT INTO [shopmanagement].[dbo].[productDetail] (email,p_id,p_price,p_qty,p_weight,p_name) VALUES ('" + email + "'," + strId + ",'" + p_Price + "','" + p_Qty + "','" + p_Weight + "','" + p_Name + "')";
                    cm = new SqlCommand(query, con);
                    cm.ExecuteNonQuery();
                    cm.Dispose();
                    con.Close();
                    MessageBox.Show("Product Added Successfully");
                    this.Close();
                }
                else
                {
                    da.Close();
                    cm.Dispose();
                    con.Close();
                    string strId = "1";
                    string p_Name = textBox1.Text;
                    string p_Price = textBox2.Text;
                    string p_Qty = textBox3.Text;
                    string p_Weight = textBox4.Text;
                    con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                    con.Open();

                    query = "INSERT INTO [shopmanagement].[dbo].[productDetail] (email,p_id,p_price,p_qty,p_weight,p_name) VALUES ('" + email + "'," + strId + ",'" + p_Price + "','" + p_Qty + "','" + p_Weight + "','" + p_Name + "')";
                    cm = new SqlCommand(query, con);

                    cm.ExecuteNonQuery();
                    cm.Dispose();
                    con.Close();
                    MessageBox.Show("Product Added Successfully");
                    this.Close();
                }
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
