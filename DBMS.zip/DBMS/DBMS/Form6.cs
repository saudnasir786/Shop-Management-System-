﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Azure;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DBMS
{
    public partial class Form6 : Form
    {
        public string email { get; set; }
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Enter Product ID");
            }
            else
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                con.Open();
                string query = "SELECT * FROM [shopmanagement].[dbo].[productDetail] WHERE p_id= '" + textBox1.Text + "' AND email='" + email + "'";
                SqlCommand cm = new SqlCommand(query, con);
                SqlDataReader da = cm.ExecuteReader();
                if (da.Read())
                {
                    da.Close();
                    cm.Dispose();
                    con.Close();
                    con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
                    con.Open();
                    query = "DELETE FROM [shopmanagement].[dbo].[productDetail] WHERE p_id= '" + textBox1.Text + "' AND email='"+email+"'";
                    cm = new SqlCommand(query, con);
                    cm.ExecuteNonQuery();
                    cm.Dispose();
                    con.Close();
                    MessageBox.Show("Product Deleted Successfully");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Product Not Found");

                }
            }
        }
    }
}
