﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Azure;
using System.Collections;

namespace DBMS
{
    public partial class Form4 : Form
    {
        public string email { get; set; }
        public Form4()
        {

            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            label4.Text = "Product Details";
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            string query = "select * from [shopmanagement].[dbo].[user] where email='" + email + "'";
            SqlCommand cm = new SqlCommand(query, con);

            SqlDataReader da = cm.ExecuteReader();
            da.Read();
            label3.Text = da["name"].ToString();
            da.Close();
            con.Close();

            con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            query = "SELECT p_id AS ID, p_name AS Name, p_price AS Price, p_qty AS Quantity, p_weight AS Weight FROM [shopmanagement].[dbo].[productDetail] WHERE email = '" + email + "'";
            cm = new SqlCommand(query, con);
            var reader = cm.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            dataGridView1.DataSource = table;
            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.email = email;
            form7.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.email = email;
            form5.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.email = email;
            form6.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label4.Text = "Product Details";
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            string query = "SELECT p_id AS ID, p_name AS Name, p_price AS Price, p_qty AS Quantity, p_weight AS Weight FROM [shopmanagement].[dbo].[productDetail] WHERE email = '" + email + "'";
            SqlCommand cm = new SqlCommand(query, con);
            var reader = cm.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            dataGridView1.DataSource = table;
            con.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.email = email;
            form8.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label4.Text = "Sold Product Details";
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-GO37J0N\\SQLEXPRESS;Initial Catalog=shopmanagement;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
            con.Open();
            string query = "SELECT sale_id AS Sale_ID, p_id AS Product_ID, p_name AS Product_Name, p_price AS Total_Price, p_qty AS Total_Quantity FROM [shopmanagement].[dbo].[sale] WHERE email = '" + email + "'";
            SqlCommand cm = new SqlCommand(query, con);
            var reader = cm.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            dataGridView1.DataSource = table;
            con.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
